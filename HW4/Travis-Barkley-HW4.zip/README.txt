Travis Barkley HW4 

use make all to compile 
use java ProducerConsumer to run the program 

thank you!
