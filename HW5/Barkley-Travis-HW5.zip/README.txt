I wrote this assignment in C++, which took some getting back into. I haven't done it since highschool:). 
I am not getting the exact answers as the given ones but I'm not sure exactly what's wrong. 
In my zip i have the two test examples given, sorry if I was not supposed to leave them in. 
